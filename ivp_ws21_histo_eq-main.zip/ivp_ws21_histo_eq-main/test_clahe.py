import utils, clahe

utils.apply(clahe, "test.jpg")