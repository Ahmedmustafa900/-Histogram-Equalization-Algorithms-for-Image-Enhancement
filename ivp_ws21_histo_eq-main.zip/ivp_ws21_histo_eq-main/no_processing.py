def process(image):
    """A process function that does nothing"""
    return image